# Proyecto Matematicas Discretas 2

## Dust Car

Proyecto final del curso Matematicas Discretas II

### Realizado Por

- Gabriel Correa Cardenas - 202073013
- Juan Camilo Varela Ocoro - 202060166

### Requisitos

- `nodejs 16.5.1`
- `yarn 1.22.19`

### Instrucciones

- Instalar Dependencias: `yarn`
- Modo Desarrollo: `yarn dev`
- Compilar Para Produccion: `yarn build`
